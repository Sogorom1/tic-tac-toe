﻿using System.Windows;

namespace TicTacToeGame
{
    public partial class MenuDialog : Window
    {
        public MenuDialog()
        {
            InitializeComponent();
        }

        private void Yes_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
        }

        private void No_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
