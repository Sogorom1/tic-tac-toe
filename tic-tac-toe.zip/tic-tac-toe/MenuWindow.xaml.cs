﻿using System.Windows;
using System.Windows.Controls;

namespace TicTacToeGame
{
    public partial class MainWindow : Window
    {
        private MenuWindow menuWindow;
        private char currentPlayer = 'X';
        private char[,] board = new char[3, 3];

        public MainWindow(MenuWindow menuWindow)
        {
            InitializeComponent();
            this.menuWindow = menuWindow;
            InitializeGame();
        }
        private void InitializeGame()
        {
            for (int row = 0; row < 3; row++)
            {
                for (int col = 0; col < 3; col++)
                {
                    board[row, col] = '-';
                }
            }
        }
        private void MenuButton_Click(object sender, RoutedEventArgs e)
        {
            MenuDialog menuDialog = new MenuDialog();
            bool? dialogResult = menuDialog.ShowDialog();

            if (dialogResult == true)
            {
                // Return to menu
                menuWindow.Show();
                Close();
            }
            else
            {
                // Continue the game
            }
        }

        private void OnButtonClick(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            int row = Grid.GetRow(button);
            int col = Grid.GetColumn(button);

            if (board[row, col] == '-')
            {
                board[row, col] = currentPlayer;
                button.Content = currentPlayer;
                CheckForWinner();
                currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
            }
        }


        private void CheckForWinner()
        {
            for (int i = 0; i < 3; i++)
            {
                if (board[i, 0] != '-' && board[i, 0] == board[i, 1] && board[i, 1] == board[i, 2])
                {
                    MessageBox.Show($"Player {board[i, 0]} wins!");
                    return;
                }

                if (board[0, i] != '-' && board[0, i] == board[1, i] && board[1, i] == board[2, i])
                {
                    MessageBox.Show($"Player {board[0, i]} wins!");
                    return;
                }
            }

            if (board[0, 0] != '-' && board[0, 0] == board[1, 1] && board[1, 1] == board[2, 2])
            {
                MessageBox.Show($"Player {board[0, 0]} wins!");
                return;
            }
            if (board[0, 2] != '-' && board[0, 2] == board[1, 1] && board[1, 1] == board[2, 0])
            {
                MessageBox.Show($"Player {board[0, 2]} wins!");

                return;
            }

            bool isDraw = true;
            foreach (char cell in board)
            {
                if (cell == '-')
                {
                    isDraw = false;
                    break;
                }
            }

            if (isDraw)
            {
                MessageBox.Show("It's a draw!");
                menuWindow.UpdateStatistics(false, false, true); 
                Close();
                return;
            }
        }
    }
}
