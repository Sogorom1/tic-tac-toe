﻿using System.Windows;

namespace TicTacToeGame
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            MenuWindow menuWindow = new MenuWindow();
            menuWindow.Show();
        }
    }
}
