﻿using System.Windows;

namespace TicTacToeGame
{
    public partial class MenuWindow : Window
    {
        private int totalGamesPlayed = 0;
        private int playerXWins = 0;
        private int playerOWins = 0;
        private int draws = 0;

        public MenuWindow()
        {
            InitializeComponent();
            UpdateStatisticsText();
        }

        private void StartGame_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow(this);
            mainWindow.Show();
            this.Hide();
        }

        public void UpdateStatistics(bool playerXWin, bool playerOWin, bool isDraw)
        {
            totalGamesPlayed++;

            if (playerXWin)
                playerXWins++;
            else if (playerOWin)
                playerOWins++;
            else if (isDraw)
                draws++;

            UpdateStatisticsText();
        }

        private void UpdateStatisticsText()
        {
            statisticsText.Text = $"Total Games: {totalGamesPlayed}\nPlayer X Wins: {playerXWins}\nPlayer O Wins: {playerOWins}\nDraws: {draws}";
        }
        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown(); 
        }

    }
}
